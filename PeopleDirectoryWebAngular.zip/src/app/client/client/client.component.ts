import { Component } from '@angular/core';
import {Person} from "../../shared/interfaces/person.model";
import {ClientService} from "../../services/ClientService";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {HttpClient, HttpClientModule} from "@angular/common/http";
import { MatTableDataSource } from '@angular/material/table';
import { DataSource } from '@angular/cdk/table';
import {debounceTime, distinctUntilChanged, filter, map, Observable, of, Subject, switchMap} from "rxjs";
import { Router } from '@angular/router';



@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrl: './client.component.scss'
})



export class ClientComponent {
  searchTerm: string = '';
  dataSource = new MatTableDataSource<Person>();
  displayedColumns: string[] = ['name', 'surname','gender']
  filteredClients: Person[] = [];
  searchValue: string = '';
  private searchTerms = new Subject<string>();
  countries: string[] = []; // Array to hold country options
  cities: string[] = []; // Array to hold city options
  selectedCountry: string = '';
  selectedCity: string = '';

  constructor(private clientService: ClientService,private http: HttpClient,private router: Router) { }

  ngOnInit(): void {
    this.getClient();

    this.searchTerms.pipe(
      debounceTime(300),
      distinctUntilChanged(),
      filter(term => term.length >= 2 || term.length === 0),
      switchMap(term => this.clientService.searchClients(term)),
    ).subscribe(data => {
      this.filteredClients = data;
      this.updateAvailableCountriesAndCities();
    }, error => console.error(error));

  }

  getClient(): void {
    this.clientService.getClients().subscribe(persons => {
      this.dataSource.data = persons;
      this.filteredClients = persons;
      this.updateAvailableCountriesAndCities();
    });
  }


  onKeyUp() {
    if(this.searchValue !== "")
    {
      this.searchTerms.next(this.searchValue);
    }else{
      this.getClient();
    }

  }


  onCountryChange(): void {
    this.filteredClients = this.filteredClients.filter(client =>
      !this.selectedCountry || client.country === this.selectedCountry
    );

    if (this.selectedCity) {
      this.onCityChange();
    }
  }

  onCityChange(): void {
    this.filteredClients = this.filteredClients.filter(client =>
      (!this.selectedCountry || client.country === this.selectedCountry) &&
      (!this.selectedCity || client.city === this.selectedCity)
    );
  }

  updateAvailableCountriesAndCities(): void {
    this.countries = Array.from(new Set(this.filteredClients.map(client => client.country)));
    this.cities = Array.from(new Set(this.filteredClients.map(client => client.city)));
  }

  onClientClick(client: Person) {
    this.router.navigate(['client', client.id]);
  }

  isLoggedIn(): boolean {
    return this.clientService.isLoggedIn();
  }

  logout(){
    this.clientService.logout();
  }

  

}
