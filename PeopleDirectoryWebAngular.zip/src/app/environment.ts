export const environment = {
  production: false,
  apiUrl: 'https://localhost:7158/api/'
};
