import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { ClientService } from '../services/ClientService';
import { catchError, throwError } from 'rxjs';
import { Person } from '../shared/interfaces/person.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
  styleUrl: './client-details.component.scss'
})
export class ClientDetailsComponent {
  isLoading = false;
  client: Person | null = null;
  clientForm: FormGroup;
  
  constructor(
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private clientService: ClientService,
    private router: Router,
  ) { 

    this.clientForm = this.fb.group({
      id: [{ value: null}],
      name: ['', Validators.required],
      surname: ['', Validators.required],
      city: ['', Validators.required],
      country: ['', Validators.required],
      mobileNumber: ['', Validators.pattern(/^\d{3}-\d{3}-\d{4}$/)],
      emailAddress: ['', [Validators.required, Validators.email]],
      gender: [''],
    });
  }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      const clientId = parseInt(params.get('id') || '', 10);
      this.getClientDetails(clientId);
    });
  }

  updateClient(){
    if(this.client)
      {
        this.clientService.updateClient(this.clientForm.value)
        .subscribe(updatedClient => {
          console.log('Client updated successfully:', updatedClient);
          this.client = updatedClient;
          this.router.navigate(['home']);
        }, error => {
          console.error('Error updating client:', error);
        });
      }else{
        this.clientService.createClient(this.clientForm.value).subscribe(newClient =>{
          this.router.navigate(['home']);
        });
      }
    
  }
  getClientDetails(clientId: number) {
    this.isLoading = true;
    this.clientService.getClientById(clientId)
      .pipe(
        catchError(error => {
          console.error('Error fetching client details:', error);
          this.isLoading = false;
          return throwError(() => new Error('Error fetching client details')); // Handle errors appropriately
        })
      )
      .subscribe(client => {
        this.clientForm.patchValue(client);
        this.isLoading = false;
        this.client = client;
      });
  }

  isLoggedIn(): boolean {
    return this.clientService.isLoggedIn();
  }
  

  deleteClient(){
    if(this.client)
    this.clientService.deleteClient(this.client.id).subscribe(
      () => {
        this.router.navigate(['home']);
      },
      (error) => {
        console.error('Error deleting item:', error);
      }
    );
  }
  newClient(){
    this.clientForm = this.fb.group({
      id: [{ value: null}],
      name: ['', Validators.required],
      surname: ['', Validators.required],
      city: ['', Validators.required],
      country: ['', Validators.required],
      mobileNumber: ['', Validators.pattern(/^\d{3}-\d{3}-\d{4}$/)],
      emailAddress: ['', [Validators.required, Validators.email]],
      gender: [''],
    });
    this.client = null;
  }
  

}
