// person.model.ts
export interface Person {
  id: number;
  name: string;
  surname: string;
  country: string;
  city: string;
  contactDetails: ContactDetails;
  personalInfo: PersonalInfo;
}

export interface ContactDetails {
  email: string;
  phone: string;
  address: string;
}

export interface PersonalInfo {
  age: number;
  gender: string;

}
