import {Injectable} from "@angular/core";
import {catchError, map, Observable, of, tap, throwError} from "rxjs";
import {Person} from "../shared/interfaces/person.model";
import {HttpClient, HttpHeaders} from "@angular/common/http";
import {environment} from "../environment";


@Injectable({
  providedIn: 'root'
})
export class ClientService {

  private apiUrl = environment.apiUrl;
  constructor(private http: HttpClient) {
    const localStorage = document.defaultView?.localStorage;
   }

   private setHeaders(): HttpHeaders {
    const token = localStorage.getItem("token");
    if (!token) {
      throw new Error("No token found in local storage");
    }
    return new HttpHeaders({ Authorization: `Bearer ${token}` });
  }


  getClients(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'Client');
  }

  searchClients(searchTerm: string): Observable<Person[]> {
    const url = searchTerm ?  this.apiUrl +`Client/search?query=${searchTerm}`
      : this.apiUrl + 'Client'

    return this.http.get<any>(url)
      .pipe(
        map(response => response.result),
        catchError(error => of([]))
      );
  }

  getClientById(id: number): Observable<Person> {
    return this.http.get<Person>(this.apiUrl +`Client/${id}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  deleteClient(id: number): Observable<any> {
    return this.http
      .delete<any>(this.apiUrl + `Client/${id}`, { headers: this.setHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  
  updateClient( client: Person): Observable<Person> {
    return this.http
      .put<Person>(this.apiUrl + `Client/${client.id}`, client, { headers: this.setHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }

  createClient(client: Person): Observable<Person> {
    return this.http
      .post<Person>(this.apiUrl + "Client", client, { headers: this.setHeaders() })
      .pipe(
        catchError(this.handleError)
      );
  }
  
  private handleError(error: any): Observable<never> {
    console.error('Error fetching client details:', error);
    return throwError(() => new Error('Error fetching client details'));
  }

  login(username: string, password: string): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}Admin/login`, { username, password }).pipe(
      tap((response: { token: string; }) => {
        // Store authentication token or user data in local storage
        localStorage.setItem('token', response.token);
      })
    );
  }

  isLoggedIn(): boolean {
    const localStorage = document.defaultView?.localStorage;
    if(localStorage)
      {
        return !!localStorage.getItem('token');

      }
      return false;
  }

  logout(): void {
    localStorage.removeItem('token');
    window.location.reload();
  }

}
