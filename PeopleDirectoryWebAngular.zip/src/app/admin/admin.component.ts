import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ClientService } from '../services/ClientService';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.scss'
})
export class AdminComponent {
  username: string = '';
  password: string = '';

  passwordVisible = false;
  constructor(private clientService: ClientService,private router: Router) { }
  login() {
   
    this.clientService.login(this.username,this.password)
      .subscribe(
        response => {
          // Handle successful login response
          this.router.navigate(['home']);
        },
        error => {
          // Handle error
          console.error('Login error', error);
        }                                                                                                           
      );
  }
}
